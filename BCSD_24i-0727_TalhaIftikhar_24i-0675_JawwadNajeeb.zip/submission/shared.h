#pragma once

#include <pthread.h>
#include <semaphore.h>
#include <sys/types.h>

#define SHM_NAME            "/chrono_rift_shm"

#define MAX_PLAYERS         4
#define MAX_ENEMIES         9
#define INVENTORY_SLOTS     20
#define MAX_LONG_TERM       32
#define ACTION_LOG_LINES    10
#define ACTION_LOG_LEN      128

#define MAX_STAMINA_PLAYER  100
#define MAX_STAMINA_ENEMY   150

#define CHRONO_STUN_DURATION_NS 3000000000LL
#define CHRONO_ULTIMATE_DURATION_S 10

#define TOTAL_KILLS_TO_WIN  10

enum class WeaponType {
    None         = 0,
    SolarCore,
    LunarBlade,
    IronHalberd,
    VenomDagger,
    Thunderstaff,
    ObsidianAxe,
    Frostbow,
    SplinterStick,
    EclipseRelic,
    COUNT
};

enum class ActionType {
    None = 0,
    Strike,
    Exhaust,
    UseWeapon,
    SwapIn,
    MoveToLongTerm,
    Heal,
    Skip,
    Ultimate
};

enum class GamePhase {
    Init     = 0,
    Running  = 1,
    Ultimate = 2,
    GameOver = 3
};

enum class GameResult {
    None = 0,
    Win,
    Lose,
    Quit
};

enum class TurnOwner {
    Player = 0,
    Enemy  = 1
};

enum class ArtifactID {
    SolarCore    = 0,
    LunarBlade   = 1,
    EclipseRelic = 2,
    COUNT        = 3
};

static const int WEAPON_SLOTS[(int)WeaponType::COUNT] = {
    0,
    10,
    10,
    7,
    4,
    6,
    5,
    6,
    2,
    8,
};

static const int WEAPON_DAMAGE[(int)WeaponType::COUNT] = {
    0,
    95,
    90,
    55,
    30,
    50,
    45,
    48,
    12,
    80,
};

[[maybe_unused]] static const char* WEAPON_NAMES[(int)WeaponType::COUNT] = {
    "None",
    "Solar Core",
    "Lunar Blade",
    "Iron Halberd",
    "Venom Dagger",
    "Thunderstaff",
    "Obsidian Axe",
    "Frostbow",
    "Splinter Stick",
    "Eclipse Relic",
};

struct InventorySlot {
    WeaponType  weapon;
    bool        is_start;
};

struct LongTermEntry {
    WeaponType  weapon;
    bool        occupied;
};

struct ActionRequest {
    ActionType  type;
    int         source_id;
    bool        source_is_player;
    int         target_id;
    int         weapon_slot;
    WeaponType  swap_weapon;
};

struct PlayerCharacter {
    bool            alive;
    int             hp;
    int             max_hp;
    int             damage;
    float           stamina;
    float           speed;
    bool            stunned;
    bool            ready_to_act;

    InventorySlot   inventory[INVENTORY_SLOTS];

    LongTermEntry   long_term[MAX_LONG_TERM];
    int             long_term_count;

    bool            just_swapped_in;
    int             fill_tick;
    long long       stun_apply_ns;
};

struct EnemyCharacter {
    bool        alive;
    int         hp;
    int         max_hp;
    int         damage;
    float       stamina;
    float       speed;
    bool        stunned;
    bool        ready_to_act;

    WeaponType  held_weapon;
    int         fill_tick;
    long long   stun_apply_ns;
};

struct ArtifactEntry {
    bool    exists;
    bool    is_free;
    bool    held_by_player;
    int     holder_index;

    bool    has_waiter;
    bool    waiter_is_player;
    int     waiter_index;
};

struct ResourceTable {
    ArtifactEntry   entries[(int)ArtifactID::COUNT];
    pthread_mutex_t table_lock;
};

struct TurnControl {
    TurnOwner   owner;
    int         entity_index;
    bool        action_submitted;
    bool        action_applied;
};

struct ActionLog {
    char  lines[ACTION_LOG_LINES][ACTION_LOG_LEN];
    int   head;
    int   count;
};

struct SharedState {

    int             player_count;
    int             enemy_count;
    bool            pvp_mode;
    PlayerCharacter players[MAX_PLAYERS];
    EnemyCharacter  enemies[MAX_ENEMIES];

    int             total_kills;
    GamePhase       phase;
    GameResult      result;

    TurnControl     turn;

    sem_t           player_turn_sem[MAX_PLAYERS];
    sem_t           enemy_turn_sem[MAX_ENEMIES];
    sem_t           action_ready_sem;

    ResourceTable   resource_table;
    int             resource_hud_resolve_ttl;
    int             resource_hud_last_victim_artifact;

    ActionRequest   pending_action;

    bool            weapon_drop_pending;
    WeaponType      dropped_weapon;
    int             drop_for_player;
    bool            player_accepted_drop;
    bool            drop_decision_ready;
    sem_t           weapon_drop_sem;
    long long       weapon_drop_deadline_ns;

    bool            deadlock_modal_pending;
    int             deadlock_prompt_player;
    int             deadlock_idx_solar;
    int             deadlock_idx_lunar;
    int             deadlock_user_choice;
    char            deadlock_line_main[160];
    char            deadlock_line_opt1[120];
    char            deadlock_line_opt2[120];
    long long       deadlock_modal_deadline_ns;
    sem_t           deadlock_choice_sem;

    ActionLog       log;

    int             gui_pressed_key;
    int             gui_prompt_mode;
    int             gui_prompt_max;
    int             gui_prompt_player;
    char            gui_prompt_text[80];
    char            gui_action_label[24];
    sem_t           gui_input_sem;

    int             anim_attacker;
    bool            anim_attacker_is_player;
    int             anim_target;
    bool            anim_target_is_player;
    int             anim_damage;
    int             anim_kind;
    int             anim_frames_left;

    pid_t           arbiter_pid;
    pid_t           hip_pid;
    pid_t           asp_pid;

    int             inv_anim_player;
    int             inv_anim_place_slot;
    int             inv_anim_place_size;
    int             inv_anim_place_ttl;
    int             inv_anim_evict_slot;
    int             inv_anim_evict_size;
    int             inv_anim_evict_ttl;
    int             inv_anim_swapin_slot;
    int             inv_anim_swapin_size;
    int             inv_anim_swapin_ttl;

    pid_t           player_tid[MAX_PLAYERS];
    pid_t           enemy_tid[MAX_ENEMIES];

    pthread_mutex_t state_lock;
};

#define SHM_SIZE  sizeof(SharedState)

inline bool weapon_is_artifact(WeaponType w) {
    return (w == WeaponType::SolarCore   ||
            w == WeaponType::LunarBlade  ||
            w == WeaponType::EclipseRelic);
}

inline bool player_has_ultimate(const PlayerCharacter& p) {
    bool has_solar = false;
    bool has_lunar = false;
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (p.inventory[i].is_start) {
            if (p.inventory[i].weapon == WeaponType::SolarCore)  has_solar = true;
            if (p.inventory[i].weapon == WeaponType::LunarBlade) has_lunar = true;
        }
    }
    return has_solar && has_lunar;
}

inline int find_weapon_in_inventory(const PlayerCharacter& p, WeaponType w) {
    for (int i = 0; i < INVENTORY_SLOTS; i++) {
        if (p.inventory[i].weapon == w && p.inventory[i].is_start)
            return i;
    }
    return -1;
}
